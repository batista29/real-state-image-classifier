This file is a merged representation of the entire codebase, combined into a single document by Repomix.

# File Summary

## Purpose
This file contains a packed representation of the entire repository's contents.
It is designed to be easily consumable by AI systems for analysis, code review,
or other automated processes.

## File Format
The content is organized as follows:
1. This summary section
2. Repository information
3. Directory structure
4. Repository files (if enabled)
5. Multiple file entries, each consisting of:
  a. A header with the file path (## File: path/to/file)
  b. The full contents of the file in a code block

## Usage Guidelines
- This file should be treated as read-only. Any changes should be made to the
  original repository files, not this packed version.
- When processing this file, use the file path to distinguish
  between different files in the repository.
- Be aware that this file may contain sensitive information. Handle it with
  the same level of security as you would the original repository.

## Notes
- Some files may have been excluded based on .gitignore rules and Repomix's configuration
- Binary files are not included in this packed representation. Please refer to the Repository Structure section for a complete list of file paths, including binary files
- Files matching patterns in .gitignore are excluded
- Files matching default ignore patterns are excluded
- Files are sorted by Git change count (files with more changes are at the bottom)

# Directory Structure
````
backend/
  src/
    middlewares/
      errorHandler.js
    routes/
      imageAnalysis.routes.js
      index.js
      language.routes.js
      legacyVision.routes.js
      speech.routes.js
      vision.routes.js
    services/
      imageAnalysis.service.js
      legacyVision.service.js
      speech.service.js
      vision.service.js
  .env.example
  .gitignore
  package.json
  server.js
docs/
  ARCHITECTURE.md
frontend/
  css/
    style.css
  js/
    app.js
  index.html
README.md
repomix.config.json
````

# Files

## File: backend/src/middlewares/errorHandler.js
````javascript
module.exports = (error, req, res, next) => {
  console.error(error);
  const status = error.status || error.response?.status || 500;
  const details = error.details || error.response?.data;
  res.status(status).json({
    error: error.message || 'Erro interno do servidor',
    ...(details ? { details } : {})
  });
};
````

## File: backend/src/routes/imageAnalysis.routes.js
````javascript
const express = require('express');
const multer = require('multer');
const { analyze } = require('../services/imageAnalysis.service');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

const run = (features) => async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Envie uma imagem no campo file.' });
    const language = req.body.language || 'pt-BR';
    const result = await analyze(req.file.buffer, features, language);
    res.json(result);
  } catch (error) { next(error); }
};

router.post('/describe', upload.single('file'), run(['caption']));
router.post('/objects', upload.single('file'), run(['objects']));
router.post('/tags', upload.single('file'), run(['tags']));
router.post('/read', upload.single('file'), run(['read']));
router.post('/analyze', upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Envie uma imagem no campo file.' });
    const allowed = new Set(['caption','objects','tags','read','people','denseCaptions','smartCrops']);
    const features = String(req.body.features || 'caption,objects,tags,read').split(',').map(x => x.trim()).filter(x => allowed.has(x));
    if (!features.length) return res.status(400).json({ error: 'Nenhum recurso de imagem válido foi solicitado.' });
    res.json(await analyze(req.file.buffer, features, req.body.language || 'pt-BR'));
  } catch (error) { next(error); }
});

module.exports = router;
````

## File: backend/src/routes/index.js
````javascript
const express = require('express');
const visionRoutes = require('./vision.routes');
const speechRoutes = require('./speech.routes');
const imageRoutes = require('./imageAnalysis.routes');
const legacyVisionRoutes = require('./legacyVision.routes');
const languageRoutes = require('./language.routes');
const router = express.Router();
router.get('/health', (req, res) => res.json({ status: 'ok', service: 'ai-vision-assistant' }));
router.use('/vision', visionRoutes);
router.use('/image-analysis', imageRoutes);
router.use('/vision-legacy', legacyVisionRoutes);
router.use('/speech', speechRoutes);
router.use('/language', languageRoutes);
module.exports = router;
````

## File: backend/src/routes/language.routes.js
````javascript
const express = require('express');
const axios = require('axios');
const router = express.Router();
router.post('/analyze-text', async (req, res, next) => {
  try {
    const { plainText } = req.body;
    if (!plainText || typeof plainText !== 'string') return res.status(400).json({ error: 'Envie plainText.' });
    const url = `${process.env.LANGUAGE_ENDPOINT}/language/:analyze-text`;
    const { data } = await axios.post(url, {
      kind: 'EntityRecognition,SentimentAnalysis',
      parameters: { modelVersion: 'latest', opinionMining: 'True' },
      analysisInput: { documents: [{ id: '1', language: 'pt', text: plainText }] }
    }, { params: { 'api-version': '2023-04-01' }, headers: { 'Content-Type':'application/json','Ocp-Apim-Subscription-Key':process.env.LANGUAGE_KEY } });
    res.json(data);
  } catch (error) { next(error); }
});
module.exports = router;
````

## File: backend/src/routes/legacyVision.routes.js
````javascript
const express = require('express');
const multer = require('multer');
const { detectBrands } = require('../services/legacyVision.service');
const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });
router.post('/brands', upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Envie uma imagem no campo file.' });
    res.json(await detectBrands(req.file.buffer));
  } catch (error) { next(error); }
});
module.exports = router;
````

## File: backend/src/routes/speech.routes.js
````javascript
const express = require('express');
const multer = require('multer');
const { fast_transcription, text_to_speech } = require('../services/speech.service');
const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });
const escapeXml = text => String(text).replace(/[<>&'"]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;',"'":'&apos;','"':'&quot;'}[c]));
router.post('/fast-transcription', upload.single('audio'), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Envie um áudio no campo audio.' });
    const locales = req.body.locales ? req.body.locales.split(',').map(x => x.trim()) : ['pt-BR'];
    res.json(await fast_transcription(req.file.buffer, req.file.originalname, { locales }));
  } catch (error) { next(error); }
});
router.post('/text-to-speech', async (req, res, next) => {
  try {
    const { text, locale = 'pt-BR', voice = 'pt-BR-FranciscaNeural', outputFormat = 'audio-16khz-128kbitrate-mono-mp3' } = req.body;
    if (!text || typeof text !== 'string') return res.status(400).json({ error: 'Informe o texto.' });
    const ssml = `<speak version='1.0' xml:lang='${escapeXml(locale)}'><voice xml:lang='${escapeXml(locale)}' name='${escapeXml(voice)}'>${escapeXml(text)}</voice></speak>`;
    const audio = await text_to_speech(ssml, outputFormat);
    res.type('audio/mpeg').send(Buffer.from(audio));
  } catch (error) { next(error); }
});
module.exports = router;
````

## File: backend/src/routes/vision.routes.js
````javascript
const express = require('express');
const multer = require('multer');
const { document_intelligence } = require('../services/vision.service');
const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });
router.post('/document-intelligence', upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Envie um arquivo no campo file.' });
    res.json(await document_intelligence(req.file.buffer));
  } catch (error) { next(error); }
});
module.exports = router;
````

## File: backend/src/services/imageAnalysis.service.js
````javascript
const axios = require('axios');

const analyze = async (fileBuffer, features, language = 'pt-BR') => {
  const endpoint = process.env.IMAGE_ANALYSIS_ENDPOINT;
  const key = process.env.IMAGE_ANALYSIS_KEY;
  if (!endpoint || !key) throw new Error('IMAGE_ANALYSIS_ENDPOINT/IMAGE_ANALYSIS_KEY não configurados.');

  const url = `${endpoint.replace(/\/$/, '')}/computervision/imageanalysis:analyze`;
  const { data } = await axios.post(url, fileBuffer, {
    params: {
      'api-version': process.env.IMAGE_ANALYSIS_API_VERSION || '2024-02-01',
      features: features.join(','),
      language
    },
    headers: {
      'Ocp-Apim-Subscription-Key': key,
      'Content-Type': 'application/octet-stream'
    },
    maxBodyLength: Infinity
  });
  return data;
};

module.exports = { analyze };
````

## File: backend/src/services/legacyVision.service.js
````javascript
const axios = require('axios');

const detectBrands = async (fileBuffer) => {
  const endpoint = process.env.LEGACY_VISION_ENDPOINT;
  const key = process.env.LEGACY_VISION_KEY;
  if (!endpoint || !key) throw new Error('LEGACY_VISION_ENDPOINT/LEGACY_VISION_KEY não configurados para Brands.');
  const url = `${endpoint.replace(/\/$/, '')}/vision/v${process.env.LEGACY_VISION_API_VERSION || '3.2'}/analyze`;
  const { data } = await axios.post(url, fileBuffer, {
    params: { visualFeatures: 'Brands' },
    headers: { 'Ocp-Apim-Subscription-Key': key, 'Content-Type': 'application/octet-stream' }
  });
  return data;
};
module.exports = { detectBrands };
````

## File: backend/src/services/speech.service.js
````javascript
const axios = require('axios');

const fast_transcription = async (fileBuffer, fileName, definition) => {
  const url = `${process.env.SPEECH_ENDPOINT}/speechtotext/transcriptions:transcribe`;
  const form = new FormData();
  form.append('audio', new Blob([fileBuffer]), fileName);
  form.append('definition', JSON.stringify(definition));
  const { data } = await axios.post(url, form, {
    params: { 'api-version': '2025-10-15' },
    headers: { 'Ocp-Apim-Subscription-Key': process.env.SPEECH_KEY },
    maxBodyLength: Infinity
  });
  return data;
};

const text_to_speech = async (ssml, outputFormat) => {
  const region = process.env.SPEECH_REGION;
  if (!region || !process.env.SPEECH_KEY) throw new Error('SPEECH_REGION/SPEECH_KEY não configurados.');
  const url = `https://${region}.tts.speech.microsoft.com/cognitiveservices/v1`;
  const { data } = await axios.post(url, ssml, {
    headers: {
      'Ocp-Apim-Subscription-Key': process.env.SPEECH_KEY,
      'Content-Type': 'application/ssml+xml',
      'X-Microsoft-OutputFormat': outputFormat,
      'User-Agent': 'ai-vision-assistant'
    },
    responseType: 'arraybuffer'
  });
  return data;
};
module.exports = { fast_transcription, text_to_speech };
````

## File: backend/src/services/vision.service.js
````javascript
const axios = require('axios');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

const document_intelligence = async (fileBuffer) => {
  const endpoint = process.env.VISION_ENDPOINT;
  const key = process.env.VISION_KEY;
  if (!endpoint || !key) throw new Error('VISION_ENDPOINT/VISION_KEY não configurados.');
  const url = `${endpoint.replace(/\/$/, '')}/documentintelligence/documentModels/prebuilt-layout:analyze`;
  const { data, headers, status } = await axios.post(url, fileBuffer, {
    params: { features: 'ocr.highResolution,ocr.formula,ocr.font', 'api-version': '2024-11-30' },
    headers: { 'Content-Type': 'application/octet-stream', 'Ocp-Apim-Subscription-Key': key },
    maxBodyLength: Infinity
  });
  if (status !== 202) return { text: data?.analyzeResult?.content || data };
  return { text: await document_intelligence_response(headers['operation-location']) };
};

const document_intelligence_response = async (url) => {
  if (!url) throw new Error('Azure não retornou operation-location.');
  await delay(3000);
  for (let attempts = 0; attempts < 30; attempts++) {
    const { data } = await axios.get(url, { headers: { 'Ocp-Apim-Subscription-Key': process.env.VISION_KEY } });
    if (data.status === 'succeeded') return data.analyzeResult?.content || '';
    if (data.status === 'failed') {
      const error = new Error('Falha ao analisar o documento'); error.status = 502; error.details = data; throw error;
    }
    await delay(1500);
  }
  const error = new Error('Tempo limite excedido ao aguardar a análise do documento'); error.status = 504; throw error;
};
module.exports = { document_intelligence };
````

## File: backend/.env.example
````
PORT=3000

# Azure Document Intelligence - OCR de documentos/notas fiscais
VISION_ENDPOINT=https://<seu-recurso>.cognitiveservices.azure.com
VISION_KEY=

# Azure AI Vision Image Analysis 4.0 - descrição, objetos, tags/read
IMAGE_ANALYSIS_ENDPOINT=https://<seu-recurso>.cognitiveservices.azure.com
IMAGE_ANALYSIS_KEY=
IMAGE_ANALYSIS_API_VERSION=2024-02-01

# Opcional: endpoint legado Computer Vision v3.2 para Brands
# O recurso de Brands não está exposto no conjunto de features do Image Analysis 4.0.
LEGACY_VISION_ENDPOINT=https://<regiao>.api.cognitive.microsoft.com
LEGACY_VISION_KEY=
LEGACY_VISION_API_VERSION=3.2

# Azure Speech
SPEECH_ENDPOINT=https://<seu-recurso>.api.cognitive.microsoft.com
SPEECH_KEY=
SPEECH_REGION=

# Azure AI Language (opcional)
LANGUAGE_ENDPOINT=https://<seu-recurso>.cognitiveservices.azure.com
LANGUAGE_KEY=
````

## File: backend/.gitignore
````
node_modules/
.env
npm-debug.log*
````

## File: backend/package.json
````json
{
  "name": "ai-vision-assistant",
  "version": "1.0.0",
  "description": "Backend Node.js/Express para integrar Azure AI Vision, Document Intelligence e Speech",
  "main": "server.js",
  "type": "commonjs",
  "scripts": {"start":"node server.js","dev":"nodemon server.js"},
  "engines": {"node": ">=20"},
  "dependencies": {"axios":"^1.7.9","cors":"^2.8.5","dotenv":"^16.4.7","express":"^4.21.2","multer":"^1.4.5-lts.1"},
  "devDependencies": {"nodemon":"^3.1.9"}
}
````

## File: backend/server.js
````javascript
require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const routes = require('./src/routes');
const errorHandler = require('./src/middlewares/errorHandler');

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use('/api', routes);
app.use(express.static(path.join(__dirname, '../frontend')));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});
app.use(errorHandler);

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`AI Vision Assistant: http://localhost:${port}`));
````

## File: docs/ARCHITECTURE.md
````markdown
# Arquitetura

```text
Browser (HTML/CSS/JS)
        |
        | HTTP /api
        v
Node.js + Express
   |       |        |
   v       v        v
Document  Image    Speech
Intel.    Analysis  TTS/STT
   |       |        |
   +-------+--------+
           |
           v
       Azure AI
```

## Segurança

- Chaves somente no backend.
- `.env` não deve ser versionado.
- Frontend chama apenas `/api/...`.

## Nota fiscal

1. Upload multipart.
2. Document Intelligence faz OCR.
3. Backend devolve o texto.
4. Frontend envia texto ao TTS.
5. Áudio é reproduzido no navegador.
````

## File: frontend/css/style.css
````css
:root{font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif;color:#17202a;background:#f4f1eb}*{box-sizing:border-box}body{margin:0}.app{max-width:1100px;margin:auto;padding:32px 20px}header{display:flex;justify-content:space-between;gap:24px;align-items:flex-start;margin-bottom:28px}.eyebrow{font-size:12px;letter-spacing:.14em;color:#6b6259}h1{font-size:44px;margin:8px 0 6px;letter-spacing:-.04em}header p{margin:0;color:#6d675f}.status{border:1px solid #d6d0c8;background:#fff;padding:9px 12px;border-radius:999px;font-size:13px}.hero,.result,.tools>div{background:#fff;border:1px solid #ddd7cf;border-radius:20px;padding:22px;box-shadow:0 10px 35px #00000008}.drop{border:2px dashed #c8c0b7;border-radius:16px;padding:42px 20px;text-align:center;cursor:pointer;display:grid;gap:8px}.drop:hover{border-color:#6b6259}.icon{font-size:30px}.drop span,.drop small{color:#7b736b}.actions{display:flex;gap:10px;margin-top:14px}.actions select,.actions button,button{font:inherit;border:1px solid #d2cbc2;border-radius:10px;padding:11px 14px;background:#fff}.actions select:first-child{flex:1}.actions button,button{cursor:pointer;background:#17202a;color:#fff;border-color:#17202a}.actions button:disabled{opacity:.45;cursor:not-allowed}.result{margin-top:18px;min-height:300px}.result-head{display:flex;justify-content:space-between}.result h2{margin:0 0 16px}pre{white-space:pre-wrap;word-break:break-word;background:#f7f5f2;border-radius:12px;padding:16px;min-height:150px;color:#39342f}audio{width:100%;margin-top:14px}.hidden{display:none}.preview img{max-width:100%;max-height:280px;border-radius:12px;margin-bottom:12px}.tools{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:18px}.tools h3{margin-top:0}.tools textarea{width:100%;min-height:120px;resize:vertical;border:1px solid #d2cbc2;border-radius:10px;padding:12px;font:inherit;margin-bottom:10px}.tools input{display:block;margin-bottom:12px}footer{color:#777067;font-size:12px;padding:20px 4px}@media(max-width:720px){header,.actions,.tools{display:block}.status{margin-top:15px;width:max-content}.actions>*{width:100%;margin-top:10px}h1{font-size:36px}.tools>div+div{margin-top:18px}}
````

## File: frontend/js/app.js
````javascript
const $ = id => document.getElementById(id);
const state = { file:null };
const api = (path, options={}) => fetch(`/api${path}`, options);

async function health(){try{const r=await api('/health'); $('status').textContent=r.ok?'● backend online':'● backend offline';}catch{$('status').textContent='● backend offline'}}
function setFile(file){state.file=file;$('fileName').textContent=file?`${file.name} • ${(file.size/1024/1024).toFixed(2)} MB`:'';$('process').disabled=!file;if(file && file.type.startsWith('image/')){$('preview').classList.remove('hidden');$('preview').innerHTML='';const img=document.createElement('img');img.src=URL.createObjectURL(file);$('preview').appendChild(img)}else $('preview').classList.add('hidden')}
$('drop').onclick=()=> $('file').click();$('file').onchange=e=>setFile(e.target.files[0]);['dragover','dragenter'].forEach(e=>$('drop').addEventListener(e,x=>{x.preventDefault()}));$('drop').ondrop=e=>{e.preventDefault();setFile(e.dataTransfer.files[0])};
async function postFile(path,file,fields={}){const form=new FormData();form.append('file',file);Object.entries(fields).forEach(([k,v])=>form.append(k,v));const r=await api(path,{method:'POST',body:form});if(!r.ok)throw new Error((await r.json()).error||'Falha na API');return r.json()}
async function tts(text){const r=await api('/speech/text-to-speech',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text,voice:$('voice').value,locale:'pt-BR'})});if(!r.ok)throw new Error('Falha ao gerar áudio');return URL.createObjectURL(await r.blob())}
function extractText(data){return data.text||data.captionResult?.text||data.readResult?.content||JSON.stringify(data,null,2)}
$('process').onclick=async()=>{if(!state.file)return;const op=$('operation').value;$('process').disabled=true;$('state').textContent='processando…';$('text').textContent='';$('audio').classList.add('hidden');$('extra').innerHTML='';try{let data,text;if(op==='receipt'){data=await postFile('/vision/document-intelligence',state.file);text=extractText(data);$('text').textContent=text;const spoken=`Informações extraídas do documento. ${text}`;$('state').textContent='gerando áudio…';$('audio').src=await tts(spoken);$('audio').classList.remove('hidden')}else if(op==='brands'){data=await postFile('/vision-legacy/brands',state.file);text=extractText(data);$('text').textContent=text;$('state').textContent='concluído'}else{data=await postFile(`/image-analysis/${op}`,state.file,{language:'pt-BR'});text=extractText(data);$('text').textContent=text;$('state').textContent='gerando áudio…';$('audio').src=await tts(text);$('audio').classList.remove('hidden');} }catch(e){$('text').textContent=`Erro: ${e.message}`;$('state').textContent='erro'}finally{$('process').disabled=!state.file}};
$('speak').onclick=async()=>{const text=$('freeText').value.trim();if(!text)return;try{$('freeAudio').src=await tts(text);$('freeAudio').classList.remove('hidden')}catch(e){alert(e.message)}};
$('transcribe').onclick=async()=>{const file=$('audioFile').files[0];if(!file)return;const form=new FormData();form.append('audio',file);form.append('locales','pt-BR');try{const r=await api('/speech/fast-transcription',{method:'POST',body:form});const data=await r.json();if(!r.ok)throw new Error(data.error||'Falha');$('stt').textContent=data.combinedPhrases?.map(x=>x.text).join('\n')||JSON.stringify(data,null,2)}catch(e){$('stt').textContent=`Erro: ${e.message}`}};
health();
````

## File: frontend/index.html
````html
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AI Vision Assistant</title><link rel="stylesheet" href="css/style.css"></head><body>
<div class="app"><header><div><span class="eyebrow">AZURE AI • VISION + SPEECH</span><h1>AI Vision Assistant</h1><p>Envie uma imagem ou documento e transforme informações visuais em texto e voz.</p></div><div id="status" class="status">● verificando</div></header>
<main><section class="hero"><div class="drop" id="drop"><input id="file" type="file" accept="image/*,.pdf" hidden><div class="icon">＋</div><strong id="dropTitle">Arraste um arquivo aqui</strong><span>ou clique para selecionar • imagem ou PDF</span><small id="fileName"></small></div>
<div class="actions"><select id="operation"><option value="receipt">Nota fiscal → texto + áudio</option><option value="describe">Descrever imagem</option><option value="objects">Detectar objetos</option><option value="tags">Detectar tags</option><option value="brands">Detectar marcas</option><option value="read">Ler texto da imagem</option></select><select id="voice"><option value="pt-BR-FranciscaNeural">Francisca • pt-BR</option><option value="pt-BR-AntonioNeural">Antônio • pt-BR</option><option value="pt-BR-BrendaNeural">Brenda • pt-BR</option></select><button id="process" disabled>Processar</button></div></section>
<section class="result"><div class="result-head"><h2>Resultado</h2><span id="state"></span></div><div id="preview" class="preview hidden"></div><pre id="text">Envie um arquivo para começar.</pre><div id="extra"></div><audio id="audio" controls class="hidden"></audio></section>
<section class="tools"><div><h3>Texto → áudio</h3><textarea id="freeText" placeholder="Digite um texto para gerar fala..."></textarea><button id="speak">Gerar áudio</button><audio id="freeAudio" controls class="hidden"></audio></div><div><h3>Áudio → texto</h3><input id="audioFile" type="file" accept="audio/*"><button id="transcribe">Transcrever</button><pre id="stt">—</pre></div></section></main><footer>As chaves ficam somente no backend (.env). Nunca coloque credenciais Azure no JavaScript do navegador.</footer></div><script src="js/app.js"></script></body></html>
````

## File: README.md
````markdown
# AI Vision Assistant

Projeto full-stack em **HTML/CSS/JavaScript puro + Node.js/Express** para integrar serviços de visão, OCR e fala da Azure.

## Fluxo principal

`Nota fiscal/imagem → backend → Azure → texto → Azure Speech → áudio`

O navegador nunca recebe as chaves Azure. Todas as credenciais ficam no `.env` do backend.

## Funcionalidades

- Nota fiscal → OCR com Azure Document Intelligence → texto + áudio
- Descrição de imagem → Image Analysis 4.0 `caption`
- Detecção de objetos → Image Analysis 4.0 `objects`
- Tags → Image Analysis 4.0 `tags`
- Leitura de texto em imagem → Image Analysis 4.0 `read`
- Marcas → endpoint legado Computer Vision 3.2, quando o recurso estiver disponível
- Texto → Speech
- Áudio → Speech-to-Text
- Health check

> Detecção facial não foi implementada porque o requisito fornecido informa que o recurso é destinado apenas a parceiros.

## Estrutura

```text
ai-vision-assistant/
├── backend/
│   ├── server.js
│   ├── .env.example
│   ├── package.json
│   └── src/
│       ├── routes/
│       ├── services/
│       └── middlewares/
├── frontend/
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js
└── docs/
```

## Como executar

```bash
cd backend
npm install
copy .env.example .env
npm start
```

No Linux/macOS, use `cp .env.example .env`.

Depois acesse `http://localhost:3000`.

## Variáveis

Preencha no `.env` as variáveis dos recursos Azure que você possui. O `.env.example` separa Document Intelligence, Image Analysis, endpoint legado de Brands e Speech.

## Endpoints principais

- `GET /api/health`
- `POST /api/vision/document-intelligence` — multipart `file`
- `POST /api/image-analysis/describe` — multipart `file`
- `POST /api/image-analysis/objects` — multipart `file`
- `POST /api/image-analysis/tags` — multipart `file`
- `POST /api/image-analysis/read` — multipart `file`
- `POST /api/vision-legacy/brands` — multipart `file`
- `POST /api/speech/text-to-speech` — JSON `{ text, locale, voice }`
- `POST /api/speech/fast-transcription` — multipart `audio` + `locales`

## Observações Azure

A implementação de Image Analysis usa a API 4.0 com os recursos `caption`, `objects`, `tags` e `read`. O endpoint legado é mantido separado para Brands, pois a API 4.0 atual não lista Brands entre os recursos disponíveis.
````

## File: repomix.config.json
````json
{
  "$schema": "https://repomix.com/schemas/latest/schema.json",
  "input": {
    "maxFileSize": 52428800
  },
  "output": {
    "filePath": "repomix-output.md",
    "style": "markdown",
    "filePathStyle": "target-relative",
    "parsableStyle": false,
    "fileSummary": true,
    "directoryStructure": true,
    "files": true,
    "removeComments": false,
    "removeEmptyLines": false,
    "compress": false,
    "topFilesLength": 5,
    "showLineNumbers": false,
    "truncateBase64": false,
    "copyToClipboard": false,
    "includeFullDirectoryStructure": false,
    "tokenCountTree": false,
    "git": {
      "sortByChanges": true,
      "sortByChangesMaxCommits": 100,
      "includeDiffs": false,
      "includeLogs": false,
      "includeLogsCount": 50
    }
  },
  "include": [],
  "ignore": {
    "useGitignore": true,
    "useDotIgnore": true,
    "useDefaultPatterns": true,
    "customPatterns": []
  },
  "security": {
    "enableSecurityCheck": true
  },
  "tokenCount": {
    "encoding": "o200k_base"
  }
}
````
