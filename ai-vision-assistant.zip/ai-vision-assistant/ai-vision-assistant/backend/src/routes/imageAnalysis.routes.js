const express = require('express');
const multer = require('multer');

const {
    analyzeImage
} = require('../services/imageAnalysis.service');

const router = express.Router();

const upload = multer({
    storage: multer.memoryStorage()
});


// ============================================================
// DESCRIÇÃO DA IMAGEM
// ============================================================

router.post('/describe', upload.single('file'), async (req, res, next) => {

    try {

        if (!req.file) {
            return res.status(400).json({
                error: 'Nenhum arquivo foi enviado.'
            });
        }

        const result = await analyzeImage(
            req.file.buffer,
            'caption',
            req.body.language || 'pt-BR'
        );

        res.json(result);

    } catch (error) {
        next(error);
    }
});


// ============================================================
// OBJETOS
// ============================================================

router.post('/objects', upload.single('file'), async (req, res, next) => {

    try {

        if (!req.file) {
            return res.status(400).json({
                error: 'Nenhum arquivo foi enviado.'
            });
        }

        const result = await analyzeImage(
            req.file.buffer,
            'objects',
            req.body.language || 'pt-BR'
        );

        res.json(result);

    } catch (error) {
        next(error);
    }
});


// ============================================================
// TAGS
// ============================================================

router.post('/tags', upload.single('file'), async (req, res, next) => {

    try {

        if (!req.file) {
            return res.status(400).json({
                error: 'Nenhum arquivo foi enviado.'
            });
        }

        const result = await analyzeImage(
            req.file.buffer,
            'tags',
            req.body.language || 'pt-BR'
        );

        res.json(result);

    } catch (error) {
        next(error);
    }
});


// ============================================================
// READ / OCR
// ============================================================

router.post('/read', upload.single('file'), async (req, res, next) => {

    try {

        if (!req.file) {
            return res.status(400).json({
                error: 'Nenhum arquivo foi enviado.'
            });
        }

        const result = await analyzeImage(
            req.file.buffer,
            'read',
            req.body.language || 'pt-BR'
        );

        res.json(result);

    } catch (error) {
        next(error);
    }
});


// ============================================================
// ANALYZE
// ============================================================

router.post('/analyze', upload.single('file'), async (req, res, next) => {

    try {

        if (!req.file) {
            return res.status(400).json({
                error: 'Nenhum arquivo foi enviado.'
            });
        }

        const features =
            req.body.features ||
            'caption,objects,tags,read';

        const result = await analyzeImage(
            req.file.buffer,
            features,
            req.body.language || 'pt-BR'
        );

        res.json(result);

    } catch (error) {
        next(error);
    }
});


module.exports = router;