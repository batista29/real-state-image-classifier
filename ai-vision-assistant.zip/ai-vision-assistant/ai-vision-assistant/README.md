# AI Vision Assistant

Projeto full-stack em **HTML/CSS/JavaScript puro + Node.js/Express** para integrar serviços de visão, OCR e fala da Azure.

## Fluxo principal

`Nota fiscal/imagem → backend → Azure → texto → Azure Speech → áudio`

O navegador nunca recebe as chaves Azure. Todas as credenciais ficam no `.env` do backend.

## Funcionalidades

- Nota fiscal → OCR com Azure Document Intelligence → texto + áudio
- Descrição de imagem → Image Analysis 4.0 `caption`
- Detecção de objetos → Image Analysis 4.0 `objects`
- Tags → Image Analysis 4.0 `tags`
- Leitura de texto em imagem → Image Analysis 4.0 `read`
- Marcas → endpoint legado Computer Vision 3.2, quando o recurso estiver disponível
- Texto → Speech
- Áudio → Speech-to-Text
- Health check

> Detecção facial não foi implementada porque o requisito fornecido informa que o recurso é destinado apenas a parceiros.

## Estrutura

```text
ai-vision-assistant/
├── backend/
│   ├── server.js
│   ├── .env.example
│   ├── package.json
│   └── src/
│       ├── routes/
│       ├── services/
│       └── middlewares/
├── frontend/
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js
└── docs/
```

## Como executar

```bash
cd backend
npm install
copy .env.example .env
npm start
```

No Linux/macOS, use `cp .env.example .env`.

Depois acesse `http://localhost:3000`.

## Variáveis

Preencha no `.env` as variáveis dos recursos Azure que você possui. O `.env.example` separa Document Intelligence, Image Analysis, endpoint legado de Brands e Speech.

## Endpoints principais

- `GET /api/health`
- `POST /api/vision/document-intelligence` — multipart `file`
- `POST /api/image-analysis/describe` — multipart `file`
- `POST /api/image-analysis/objects` — multipart `file`
- `POST /api/image-analysis/tags` — multipart `file`
- `POST /api/image-analysis/read` — multipart `file`
- `POST /api/vision-legacy/brands` — multipart `file`
- `POST /api/speech/text-to-speech` — JSON `{ text, locale, voice }`
- `POST /api/speech/fast-transcription` — multipart `audio` + `locales`

## Observações Azure

A implementação de Image Analysis usa a API 4.0 com os recursos `caption`, `objects`, `tags` e `read`. O endpoint legado é mantido separado para Brands, pois a API 4.0 atual não lista Brands entre os recursos disponíveis.
