const $ = (id) => document.getElementById(id);

const state = {
    file: null
};

// ============================================================
// API
// ============================================================

const api = (path, options = {}) => {
    return fetch(`/api${path}`, options);
};


// ============================================================
// STATUS DO BACKEND
// ============================================================

async function health() {
    try {
        const response = await api('/health');

        if (response.ok) {
            $('status').textContent = '● backend online';
        } else {
            $('status').textContent = '● backend offline';
        }

    } catch (error) {
        $('status').textContent = '● backend offline';
    }
}


// ============================================================
// ARQUIVO
// ============================================================

function setFile(file) {

    if (!file) {
        state.file = null;

        $('fileName').textContent = '';
        $('process').disabled = true;

        $('preview').classList.add('hidden');
        $('preview').innerHTML = '';

        return;
    }

    state.file = file;

    const sizeMB = (file.size / 1024 / 1024).toFixed(2);

    $('fileName').textContent =
        `${file.name} • ${sizeMB} MB`;

    $('process').disabled = false;


    // Preview de imagem
    if (file.type && file.type.startsWith('image/')) {

        $('preview').classList.remove('hidden');
        $('preview').innerHTML = '';

        const img = document.createElement('img');

        img.src = URL.createObjectURL(file);

        img.alt = 'Pré-visualização da imagem';

        $('preview').appendChild(img);

    } else {

        $('preview').classList.add('hidden');
        $('preview').innerHTML = '';
    }
}


// ============================================================
// UPLOAD / POST
// ============================================================

async function postFile(path, file) {
    const form = new FormData();
    form.append("file", file);

    console.log("Enviando para:", `/api${path}`);
    console.log("Arquivo:", file.name, file.type, file.size);

    const response = await fetch(`/api${path}`, {
        method: "POST",
        body: form
    });

    console.log("Status:", response.status);
    console.log("Content-Type:", response.headers.get("content-type"));

    const body = await response.text();

    console.log("Resposta:", body);

    if (!response.ok) {
        throw new Error(`Erro HTTP ${response.status}: ${body}`);
    }

    try {
        return JSON.parse(body);
    } catch {
        return {
            text: body
        };
    }
}

// ============================================================
// TEXT TO SPEECH
// ============================================================

async function tts(text) {

    if (!text || !text.trim()) {
        throw new Error(
            'Não há texto para transformar em áudio.'
        );
    }


    const response = await api(
        '/speech/text-to-speech',
        {
            method: 'POST',

            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify({
                text: text,
                voice: $('voice').value,
                locale: 'pt-BR'
            })
        }
    );


    if (!response.ok) {

        const contentType =
            response.headers.get('content-type') || '';

        const responseText =
            await response.text();

        let message =
            responseText ||
            `Erro HTTP ${response.status}`;


        if (
            contentType.includes('application/json') &&
            responseText
        ) {

            try {

                const data =
                    JSON.parse(responseText);

                message =
                    data.error ||
                    data.message ||
                    message;

            } catch (error) {
                // Mantém mensagem original
            }
        }


        throw new Error(message);
    }


    const blob =
        await response.blob();


    if (!blob.size) {

        throw new Error(
            'O Azure Speech retornou um áudio vazio.'
        );
    }


    return URL.createObjectURL(blob);
}


// ============================================================
// EXTRAÇÃO DE TEXTO
// ============================================================

function extractText(data) {

    if (!data) {
        return '';
    }


    // Document Intelligence
    if (data.text) {
        return data.text;
    }


    // Caption
    if (
        data.captionResult &&
        data.captionResult.text
    ) {

        return data.captionResult.text;
    }


    // Read
    if (
        data.readResult &&
        data.readResult.content
    ) {

        return data.readResult.content;
    }


    // Algumas respostas podem vir como content
    if (data.content) {
        return data.content;
    }


    // Caso não encontre texto,
    // mostra o JSON formatado.
    try {

        return JSON.stringify(
            data,
            null,
            2
        );

    } catch (error) {

        return String(data);
    }
}


// ============================================================
// TEXTO MAIS ADEQUADO PARA ÁUDIO
// ============================================================

function textForSpeech(data, operation) {

    if (!data) {
        return '';
    }


    // ========================================================
    // DESCRIÇÃO
    // ========================================================

    if (operation === 'describe') {

        if (
            data.captionResult &&
            data.captionResult.text
        ) {

            return data.captionResult.text;
        }

        return extractText(data);
    }


    // ========================================================
    // OBJETOS
    // ========================================================

    if (operation === 'objects') {

        const objects =
            data.objectsResult?.values ||
            data.objects ||
            [];

        if (Array.isArray(objects) && objects.length) {

            const names = objects
                .map((item) => {

                    return (
                        item.tags?.[0]?.name ||
                        item.name ||
                        item.object ||
                        null
                    );

                })
                .filter(Boolean);


            if (names.length) {

                const uniqueNames =
                    [...new Set(names)];

                return (
                    `Objetos identificados: ` +
                    uniqueNames.join(', ') +
                    '.'
                );
            }
        }

        return 'Nenhum objeto foi identificado.';
    }


    // ========================================================
    // TAGS
    // ========================================================

    if (operation === 'tags') {

        const tags =
            data.tagsResult?.values ||
            data.tags ||
            [];

        if (Array.isArray(tags) && tags.length) {

            const names = tags
                .map((tag) => {

                    return (
                        tag.name ||
                        tag
                    );

                })
                .filter(Boolean);


            if (names.length) {

                const uniqueNames =
                    [...new Set(names)];

                return (
                    `Tags identificadas: ` +
                    uniqueNames.join(', ') +
                    '.'
                );
            }
        }

        return 'Nenhuma tag foi identificada.';
    }


    // ========================================================
    // READ / OCR
    // ========================================================

    if (operation === 'read') {

        return extractText(data);
    }


    // ========================================================
    // DEFAULT
    // ========================================================

    return extractText(data);
}


// ============================================================
// PROCESSAR IMAGEM / DOCUMENTO
// ============================================================

$('process').onclick = async () => {

    if (!state.file) {
        alert("Selecione uma imagem primeiro.");
        return;
    }

    $('process').disabled = true;
    $('state').textContent = "Enviando imagem...";
    $('text').textContent = "";

    try {

        const data = await postFile(
            "/vision/document-intelligence",
            state.file
        );

        console.log("Dados recebidos:", data);

        const text =
            data.text ||
            data.content ||
            JSON.stringify(data, null, 2);

        $('text').textContent = text;
        $('state').textContent = "Concluído!";

    } catch (error) {

        console.error(error);

        $('text').textContent =
            `Erro: ${error.message}`;

        $('state').textContent = "Erro";

    } finally {

        $('process').disabled = false;

    }
};


// ============================================================
// TEXTO → ÁUDIO
// ============================================================

$('speak').onclick = async () => {

    const text =
        $('freeText').value.trim();


    if (!text) {
        return;
    }


    try {

        $('freeAudio').classList.add(
            'hidden'
        );


        $('freeAudio').src =
            await tts(text);


        $('freeAudio').classList.remove(
            'hidden'
        );

    } catch (error) {

        console.error(
            'Erro no Text-to-Speech:',
            error
        );

        alert(
            `Erro: ${error.message}`
        );
    }
};


// ============================================================
// ÁUDIO → TEXTO
// ============================================================

$('transcribe').onclick = async () => {

    const file =
        $('audioFile').files[0];


    if (!file) {
        return;
    }


    const form =
        new FormData();


    form.append(
        'audio',
        file
    );


    form.append(
        'locales',
        'pt-BR'
    );


    try {

        $('stt').textContent =
            'transcrevendo…';


        const response =
            await api(
                '/speech/fast-transcription',
                {
                    method: 'POST',
                    body: form
                }
            );


        const contentType =
            response.headers.get(
                'content-type'
            ) || '';


        const responseText =
            await response.text();


        if (!response.ok) {

            let message =
                responseText ||
                `Erro HTTP ${response.status}`;


            if (
                contentType.includes(
                    'application/json'
                ) &&
                responseText
            ) {

                try {

                    const data =
                        JSON.parse(
                            responseText
                        );

                    message =
                        data.error ||
                        data.message ||
                        message;

                } catch (error) {
                    // Mantém resposta original
                }
            }


            throw new Error(message);
        }


        if (!responseText) {

            throw new Error(
                'A API de transcrição retornou uma resposta vazia.'
            );
        }


        let data;

        try {

            data =
                JSON.parse(responseText);

        } catch (error) {

            throw new Error(
                'A API de transcrição não retornou JSON.'
            );
        }


        const phrases =
            data.combinedPhrases;


        if (
            Array.isArray(phrases) &&
            phrases.length
        ) {

            $('stt').textContent =
                phrases
                    .map(
                        (item) => item.text
                    )
                    .filter(Boolean)
                    .join('\n');

        } else {

            $('stt').textContent =
                JSON.stringify(
                    data,
                    null,
                    2
                );
        }

    } catch (error) {

        console.error(
            'Erro na transcrição:',
            error
        );


        $('stt').textContent =
            `Erro: ${error.message}`;
    }
};


// ============================================================
// DRAG AND DROP
// ============================================================

$('drop').onclick = () => {
    $('file').click();
};


$('file').onchange = (event) => {

    const file =
        event.target.files[0];

    setFile(file);
};


['dragover', 'dragenter'].forEach(
    (eventName) => {

        $('drop').addEventListener(
            eventName,
            (event) => {

                event.preventDefault();

                $('drop').classList.add(
                    'dragover'
                );
            }
        );
    }
);


['dragleave', 'drop'].forEach(
    (eventName) => {

        $('drop').addEventListener(
            eventName,
            (event) => {

                event.preventDefault();

                $('drop').classList.remove(
                    'dragover'
                );
            }
        );
    }
);


$('drop').ondrop = (event) => {

    event.preventDefault();

    const file =
        event.dataTransfer.files[0];

    setFile(file);
};


// ============================================================
// INICIALIZAÇÃO
// ============================================================

health();


// Atualiza o status periodicamente
setInterval(
    health,
    10000
);