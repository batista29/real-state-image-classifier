const $ = (id) => document.getElementById(id);

const state = {
    file: null
};

// ============================================================
// API
// ============================================================

const api = (path, options = {}) => fetch(`/api${path}`, options);

// ============================================================
// STATUS DO BACKEND
// ============================================================

async function health() {
    try {
        const response = await api('/health');
        $('status').textContent = response.ok ? '● backend online' : '● backend offline';
    } catch (error) {
        $('status').textContent = '● backend offline';
    }
}

// ============================================================
// MENSAGENS DO CHAT
// ============================================================

function addMessage(role, content) {
    const wrap = document.createElement('div');
    wrap.className = `msg ${role}`;

    const bubble = document.createElement('div');
    bubble.className = 'bubble';

    if (typeof content === 'string') {
        bubble.textContent = content;
    } else {
        bubble.appendChild(content);
    }

    wrap.appendChild(bubble);
    $('messages').appendChild(wrap);
    $('messages').scrollTop = $('messages').scrollHeight;

    return bubble;
}

function buildUserBubbleContent(text, file) {
    const container = document.createElement('div');

    if (file) {
        if (file.type && file.type.startsWith('image/')) {
            const img = document.createElement('img');
            img.src = URL.createObjectURL(file);
            img.alt = file.name;
            img.className = 'msg-thumb';
            container.appendChild(img);
        } else {
            const chip = document.createElement('div');
            chip.className = 'msg-file';
            chip.textContent = `📎 ${file.name}`;
            container.appendChild(chip);
        }
    }

    if (text) {
        const p = document.createElement('div');
        p.textContent = text;
        container.appendChild(p);
    }

    return container;
}

function buildAssistantBubbleContent(result) {
    const container = document.createElement('div');

    const pre = document.createElement('pre');
    pre.className = 'assistant-text';
    pre.textContent = result.text || '(sem texto na resposta)';
    container.appendChild(pre);

    if (result.audioDataUrl) {
        const audio = document.createElement('audio');
        audio.controls = true;
        audio.src = result.audioDataUrl;
        container.appendChild(audio);
    }

    return container;
}

// ============================================================
// ANEXO DE ARQUIVO
// ============================================================

function setFile(file) {
    state.file = file || null;

    if (!file) {
        $('fileChip').classList.add('hidden');
        $('fileChip').textContent = '';
        return;
    }

    $('fileChip').classList.remove('hidden');
    $('fileChip').textContent = `📎 ${file.name} ✕`;
}

$('attachBtn').onclick = () => {
    $('file').click();
};

$('file').onchange = (event) => {
    setFile(event.target.files[0]);
};

$('fileChip').onclick = () => {
    setFile(null);
    $('file').value = '';
};

// ============================================================
// ENVIO DA MENSAGEM
// ============================================================

$('composer').onsubmit = async (event) => {
    event.preventDefault();

    const message = $('message').value.trim();
    const file = state.file;

    if (!message && !file) {
        return;
    }

    addMessage('user', buildUserBubbleContent(message, file));

    $('message').value = '';
    setFile(null);
    $('file').value = '';
    $('send').disabled = true;

    const thinkingBubble = addMessage('assistant', 'Pensando...');

    try {
        const form = new FormData();
        form.append('message', message);
        if (file) {
            form.append('file', file);
        }

        const response = await fetch('/api/assistant/ask', {
            method: 'POST',
            body: form
        });

        const responseText = await response.text();

        let data;
        try {
            data = JSON.parse(responseText);
        } catch (error) {
            data = { text: responseText };
        }

        if (!response.ok) {
            throw new Error(data.error || `Erro HTTP ${response.status}`);
        }

        thinkingBubble.innerHTML = '';
        thinkingBubble.appendChild(buildAssistantBubbleContent(data));

    } catch (error) {
        console.error(error);
        thinkingBubble.textContent = `Erro: ${error.message}`;
    } finally {
        $('send').disabled = false;
    }
};

// ============================================================
// INICIALIZAÇÃO
// ============================================================

health();
setInterval(health, 10000);
