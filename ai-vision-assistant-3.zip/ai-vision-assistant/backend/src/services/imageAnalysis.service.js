const axios = require('axios');

const analyze = async (fileBuffer, features, language = 'pt-BR') => {
  const endpoint = process.env.IMAGE_ANALYSIS_ENDPOINT;
  const key = process.env.IMAGE_ANALYSIS_KEY;
  if (!endpoint || !key) throw new Error('IMAGE_ANALYSIS_ENDPOINT/IMAGE_ANALYSIS_KEY não configurados.');

  const url = `${endpoint.replace(/\/$/, '')}/computervision/imageanalysis:analyze`;
  const { data } = await axios.post(url, fileBuffer, {
    params: {
      'api-version': process.env.IMAGE_ANALYSIS_API_VERSION || '2024-02-01',
      features: features.join(','),
      language
    },
    headers: {
      'Ocp-Apim-Subscription-Key': key,
      'Content-Type': 'application/octet-stream'
    },
    maxBodyLength: Infinity
  });
  return data;
};

module.exports = { analyze };
