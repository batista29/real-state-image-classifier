const axios = require('axios');

const { document_intelligence } = require('./vision.service');
const { analyze } = require('./imageAnalysis.service');
const { detectBrands } = require('./legacyVision.service');
const { fast_transcription, text_to_speech } = require('./speech.service');
const { classify, detectVoice, wantsAudioToo, normalize, extractSpeechText } = require('./intent.service');

const escapeXml = (text) => String(text).replace(/[<>&'"]/g, (c) => ({
    '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;'
}[c]));

const HELP_TEXT = [
    'Posso ajudar com:',
    '- Descrever uma imagem, detectar objetos, tags ou marcas (anexe a imagem)',
    '- Extrair o texto de uma imagem ou ler uma nota fiscal/documento (anexe o arquivo)',
    '- Transcrever um áudio (anexe o arquivo de áudio)',
    '- Converter um texto em fala (ex.: "leia em voz alta: Bom dia!")',
    'Descreva o que você precisa e, se for o caso, anexe o arquivo.'
].join('\n');

// ============================================================
// EXTRAÇÃO / RESUMO DE RESULTADOS
// ============================================================

function extractText(data) {
    if (!data) return '';
    if (data.text) return data.text;
    if (data.captionResult?.text) return data.captionResult.text;
    if (data.readResult?.content) return data.readResult.content;
    if (data.content) return data.content;
    try {
        return JSON.stringify(data, null, 2);
    } catch (error) {
        return String(data);
    }
}

function summarizeObjects(data) {
    const objects = data.objectsResult?.values || data.objects || [];
    const names = objects
        .map((item) => item.tags?.[0]?.name || item.name || item.object || null)
        .filter(Boolean);
    const unique = [...new Set(names)];
    return unique.length ? `Objetos identificados: ${unique.join(', ')}.` : 'Nenhum objeto foi identificado.';
}

function summarizeTags(data) {
    const tags = data.tagsResult?.values || data.tags || [];
    const names = tags.map((tag) => tag.name || tag).filter(Boolean);
    const unique = [...new Set(names)];
    return unique.length ? `Tags identificadas: ${unique.join(', ')}.` : 'Nenhuma tag foi identificada.';
}

function summarizeBrands(data) {
    const brands = data?.result?.brands || data?.brands || [];
    const names = brands.map((brand) => brand.name).filter(Boolean);
    const unique = [...new Set(names)];
    return unique.length ? `Marcas identificadas: ${unique.join(', ')}.` : 'Nenhuma marca foi identificada.';
}

function summarizeLanguage(data) {
    const doc = data?.results?.documents?.[0];
    if (!doc) return extractText(data);

    const parts = [];

    if (doc.sentiment) {
        parts.push(`Sentimento geral: ${doc.sentiment}.`);
    }

    const entities = doc.entities || [];
    if (entities.length) {
        const names = [...new Set(entities.map((e) => e.text).filter(Boolean))];
        parts.push(`Entidades encontradas: ${names.join(', ')}.`);
    }

    return parts.length ? parts.join('\n') : extractText(data);
}

async function synthesize(text, voice) {
    if (!text || !text.trim()) return null;

    const locale = 'pt-BR';
    const ssml = `<speak version='1.0' xml:lang='${locale}'><voice xml:lang='${locale}' name='${voice}'>${escapeXml(text)}</voice></speak>`;
    const audio = await text_to_speech(ssml, 'audio-16khz-128kbitrate-mono-mp3');

    return `data:audio/mpeg;base64,${Buffer.from(audio).toString('base64')}`;
}

// ============================================================
// ORQUESTRAÇÃO PRINCIPAL
// ============================================================

async function handleAsk({ message, file }) {
    const hasFile = Boolean(file);
    const fileMimetype = file?.mimetype;
    const normalized = normalize(message);
    const voice = detectVoice(normalized);

    const { intent } = classify({ message, hasFile, fileMimetype });

    switch (intent) {
        case 'transcribe': {
            const data = await fast_transcription(file.buffer, file.originalname, { locales: ['pt-BR'] });
            const phrases = data.combinedPhrases;
            const text = Array.isArray(phrases) && phrases.length
                ? phrases.map((item) => item.text).filter(Boolean).join('\n')
                : extractText(data);
            return { intent, text, raw: data };
        }

        case 'document-intelligence': {
            const data = await document_intelligence(file.buffer);
            const text = extractText(data);
            const result = { intent, text, raw: data };
            if (wantsAudioToo(normalized)) result.audioDataUrl = await synthesize(text, voice);
            return result;
        }

        case 'describe': {
            const data = await analyze(file.buffer, ['caption'], 'pt');
            const text = data.captionResult?.text || extractText(data);
            const result = { intent, text, raw: data };
            if (wantsAudioToo(normalized)) result.audioDataUrl = await synthesize(text, voice);
            return result;
        }

        case 'objects': {
            const data = await analyze(file.buffer, ['objects'], 'pt');
            const text = summarizeObjects(data);
            const result = { intent, text, raw: data };
            if (wantsAudioToo(normalized)) result.audioDataUrl = await synthesize(text, voice);
            return result;
        }

        case 'tags': {
            const data = await analyze(file.buffer, ['tags'], 'pt');
            const text = summarizeTags(data);
            const result = { intent, text, raw: data };
            if (wantsAudioToo(normalized)) result.audioDataUrl = await synthesize(text, voice);
            return result;
        }

        case 'read': {
            const data = await analyze(file.buffer, ['read'], 'pt');
            const text = extractText(data);
            const result = { intent, text, raw: data };
            if (wantsAudioToo(normalized)) result.audioDataUrl = await synthesize(text, voice);
            return result;
        }

        case 'brands': {
            const data = await detectBrands(file.buffer);
            const text = summarizeBrands(data);
            const result = { intent, text, raw: data };
            if (wantsAudioToo(normalized)) result.audioDataUrl = await synthesize(text, voice);
            return result;
        }

        case 'analyze': {
            const data = await analyze(file.buffer, ['caption', 'objects', 'tags', 'read'], 'pt');
            const parts = [];
            if (data.captionResult?.text) parts.push(data.captionResult.text);
            parts.push(summarizeObjects(data));
            parts.push(summarizeTags(data));
            if (data.readResult?.content) parts.push(`Texto encontrado: ${data.readResult.content}`);
            const text = parts.join('\n\n');
            const result = { intent, text, raw: data };
            if (wantsAudioToo(normalized)) result.audioDataUrl = await synthesize(text, voice);
            return result;
        }

        case 'tts': {
            const textToSpeak = extractSpeechText(message);
            const audioDataUrl = await synthesize(textToSpeak, voice);
            return { intent, text: textToSpeak, audioDataUrl };
        }

        case 'language': {
            const textToAnalyze = extractSpeechText(message);
            const url = `${process.env.LANGUAGE_ENDPOINT}/language/:analyze-text`;
            const { data } = await axios.post(url, {
                kind: 'EntityRecognition,SentimentAnalysis',
                parameters: { modelVersion: 'latest', opinionMining: 'True' },
                analysisInput: { documents: [{ id: '1', language: 'pt', text: textToAnalyze }] }
            }, {
                params: { 'api-version': '2023-04-01' },
                headers: {
                    'Content-Type': 'application/json',
                    'Ocp-Apim-Subscription-Key': process.env.LANGUAGE_KEY
                }
            });
            return { intent, text: summarizeLanguage(data), raw: data };
        }

        case 'need-audio-file':
            return { intent, text: 'Para transcrever, anexe um arquivo de áudio (ex.: .mp3 ou .wav) junto com sua mensagem.' };

        case 'need-image-file':
            return { intent, text: 'Anexe uma imagem ou um PDF junto com sua mensagem para eu poder analisar.' };

        case 'help':
        default:
            return { intent: 'help', text: HELP_TEXT };
    }
}

module.exports = { handleAsk };
