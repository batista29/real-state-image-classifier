# AI Vision Assistant

Projeto full-stack em **HTML/CSS/JavaScript puro + Node.js/Express** para integrar serviços de visão, OCR e fala da Azure.

## Fluxo principal

`Pergunta em linguagem natural (+ arquivo opcional) → backend decide o serviço Azure certo → texto (+ áudio quando fizer sentido)`

O frontend agora é um chat com um único campo de pergunta e um botão de anexo — não existe mais um campo por serviço. O usuário escreve o que precisa (ex.: "descreva essa imagem", "leia essa nota fiscal", "transcreva esse áudio", "leia em voz alta: ..."), anexa um arquivo quando fizer sentido, e o backend classifica a intenção e chama o serviço Azure correspondente.

O navegador nunca recebe as chaves Azure. Todas as credenciais ficam no `.env` do backend.

## Funcionalidades

- Nota fiscal → OCR com Azure Document Intelligence → texto + áudio
- Descrição de imagem → Image Analysis 4.0 `caption`
- Detecção de objetos → Image Analysis 4.0 `objects`
- Tags → Image Analysis 4.0 `tags`
- Leitura de texto em imagem → Image Analysis 4.0 `read`
- Marcas → endpoint legado Computer Vision 3.2, quando o recurso estiver disponível
- Texto → Speech
- Áudio → Speech-to-Text
- Health check

> Detecção facial não foi implementada porque o requisito fornecido informa que o recurso é destinado apenas a parceiros.

## Estrutura

```text
ai-vision-assistant/
├── backend/
│   ├── server.js
│   ├── .env.example
│   ├── package.json
│   └── src/
│       ├── routes/
│       ├── services/
│       └── middlewares/
├── frontend/
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js
└── docs/
```

## Como executar

```bash
cd backend
npm install
copy .env.example .env
npm start
```

No Linux/macOS, use `cp .env.example .env`.

Depois acesse `http://localhost:3000`.

## Variáveis

Preencha no `.env` as variáveis dos recursos Azure que você possui. O `.env.example` separa Document Intelligence, Image Analysis, endpoint legado de Brands e Speech.

## Endpoints principais

- `GET /api/health`
- `POST /api/assistant/ask` — **endpoint único usado pelo novo frontend**. Multipart com `message` (texto do pedido) e, opcionalmente, `file` (imagem, PDF ou áudio). O backend classifica a intenção (`backend/src/services/intent.service.js`) e chama o serviço Azure correspondente (`backend/src/services/assistant.service.js`), devolvendo `{ intent, text, audioDataUrl?, raw? }`.
- `POST /api/vision/document-intelligence` — multipart `file`
- `POST /api/image-analysis/describe` — multipart `file`
- `POST /api/image-analysis/objects` — multipart `file`
- `POST /api/image-analysis/tags` — multipart `file`
- `POST /api/image-analysis/read` — multipart `file`
- `POST /api/vision-legacy/brands` — multipart `file`
- `POST /api/speech/text-to-speech` — JSON `{ text, locale, voice }`
- `POST /api/speech/fast-transcription` — multipart `audio` + `locales`
- `POST /api/language/analyze-text` — JSON `{ plainText }`

Os endpoints antigos (por serviço) continuam disponíveis, pois o `assistant.service.js` reaproveita a mesma lógica internamente — só o frontend passou a falar exclusivamente com `/api/assistant/ask`.

### Como a intenção é decidida

`intent.service.js` normaliza o texto (minúsculas, sem acento) e usa o tipo do arquivo anexado + palavras-chave em português para escolher o serviço:

| Anexo | Palavras-chave no pedido | Serviço acionado |
|---|---|---|
| imagem/PDF | "marca(s)", "logo" | Computer Vision legado — Brands |
| imagem/PDF | "nota fiscal", "recibo", "documento", "fatura" | Document Intelligence |
| imagem/PDF | "objeto(s)" | Image Analysis — objects |
| imagem/PDF | "tag(s)", "palavra-chave" | Image Analysis — tags |
| imagem/PDF | "ler", "ocr", "texto da imagem" | Image Analysis — read |
| imagem/PDF | "descreva", "o que tem" | Image Analysis — caption |
| imagem/PDF | (nenhuma palavra-chave específica) | Image Analysis combinado (caption+objects+tags+read) |
| áudio | (qualquer) | Speech — transcrição |
| nenhum | "transcrev..." | pede para anexar áudio |
| nenhum | "sentimento", "entidade(s)" | Azure AI Language |
| nenhum | "áudio", "fala", "voz", "narrar" | Speech — texto em voz (usa o texto após ":" na mensagem) |
| nenhum | outras menções a imagem sem anexo | pede para anexar o arquivo |
| nenhum | nada reconhecido | mensagem de ajuda |

Se o pedido sobre uma imagem também mencionar "em voz alta"/"narrado"/"em áudio", o backend gera automaticamente o áudio do resultado com Azure Speech.

## Observações Azure

A implementação de Image Analysis usa a API 4.0 com os recursos `caption`, `objects`, `tags` e `read`. O endpoint legado é mantido separado para Brands, pois a API 4.0 atual não lista Brands entre os recursos disponíveis.
