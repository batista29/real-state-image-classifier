module.exports = (error, req, res, next) => {
  console.error(error);
  const status = error.status || error.response?.status || 500;
  const details = error.details || error.response?.data;
  res.status(status).json({
    error: error.message || 'Erro interno do servidor',
    ...(details ? { details } : {})
  });
};
