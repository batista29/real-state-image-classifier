const axios = require('axios');

const detectBrands = async (fileBuffer) => {
  const endpoint = process.env.LEGACY_VISION_ENDPOINT;
  const key = process.env.LEGACY_VISION_KEY;
  if (!endpoint || !key) throw new Error('LEGACY_VISION_ENDPOINT/LEGACY_VISION_KEY não configurados para Brands.');
  const url = `${endpoint.replace(/\/$/, '')}/vision/v${process.env.LEGACY_VISION_API_VERSION || '3.2'}/analyze`;
  const { data } = await axios.post(url, fileBuffer, {
    params: { visualFeatures: 'Brands' },
    headers: { 'Ocp-Apim-Subscription-Key': key, 'Content-Type': 'application/octet-stream' }
  });
  return data;
};
module.exports = { detectBrands };
