const axios = require('axios');

const fast_transcription = async (fileBuffer, fileName, definition) => {
  const url = `${process.env.SPEECH_ENDPOINT}/speechtotext/transcriptions:transcribe`;
  const form = new FormData();
  form.append('audio', new Blob([fileBuffer]), fileName);
  form.append('definition', JSON.stringify(definition));
  const { data } = await axios.post(url, form, {
    params: { 'api-version': '2025-10-15' },
    headers: { 'Ocp-Apim-Subscription-Key': process.env.SPEECH_KEY },
    maxBodyLength: Infinity
  });
  return data;
};

const text_to_speech = async (ssml, outputFormat) => {
  const region = process.env.SPEECH_REGION;
  if (!region || !process.env.SPEECH_KEY) throw new Error('SPEECH_REGION/SPEECH_KEY não configurados.');
  const url = `https://${region}.tts.speech.microsoft.com/cognitiveservices/v1`;
  const { data } = await axios.post(url, ssml, {
    headers: {
      'Ocp-Apim-Subscription-Key': process.env.SPEECH_KEY,
      'Content-Type': 'application/ssml+xml',
      'X-Microsoft-OutputFormat': outputFormat,
      'User-Agent': 'ai-vision-assistant'
    },
    responseType: 'arraybuffer'
  });
  return data;
};
module.exports = { fast_transcription, text_to_speech };
