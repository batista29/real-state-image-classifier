// ============================================================
// CLASSIFICAÇÃO DE INTENÇÃO
// ------------------------------------------------------------
// Recebe a mensagem em linguagem natural (e o tipo de arquivo
// anexado, se houver) e decide qual serviço da Azure deve
// atender o pedido. É uma classificação simples por palavras-
// chave — suficiente para rotear entre os serviços já
// integrados no backend, sem exigir um modelo extra.
// ============================================================

function normalize(str) {
    return (str || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .trim();
}

function includesAny(text, words) {
    return words.some((word) => text.includes(word));
}

function detectVoice(normalizedText) {
    if (includesAny(normalizedText, ['antonio'])) return 'pt-BR-AntonioNeural';
    if (includesAny(normalizedText, ['brenda'])) return 'pt-BR-BrendaNeural';
    return 'pt-BR-FranciscaNeural';
}

// Quando o pedido é sobre uma imagem/documento, mas o usuário também
// pede para "ouvir"/"narrar" o resultado, geramos o áudio também.
function wantsAudioToo(normalizedText) {
    return includesAny(normalizedText, [
        'em audio', 'em voz alta', 'narrado', 'narrada',
        'com audio', 'e fale', 'e leia', 'ouvir o resultado',
        'tambem em audio', 'ler isso para mim'
    ]);
}

const WORDS = {
    brands: ['marca', 'marcas', 'logo', 'logotipo'],
    document: ['nota fiscal', 'recibo', 'cupom fiscal', 'documento', 'fatura', 'layout do documento'],
    objects: ['objeto', 'objetos'],
    tags: ['tag', 'tags', 'palavra-chave', 'palavras-chave', 'palavra chave', 'palavras chave'],
    read: ['ler o texto', 'ler texto', 'ocr', 'texto da imagem', 'que texto tem', 'transcreva o texto', 'transcrever o texto'],
    describe: ['descreva', 'descrever', 'o que tem nessa', 'o que tem nesta', 'o que e isso', 'do que se trata', 'legenda', 'explique a imagem', 'explique essa imagem'],
    transcribe: ['transcrev'],
    language: ['sentimento', 'entidade', 'entidades', 'opiniao', 'analise esse texto', 'analisar esse texto', 'analise de texto'],
    tts: ['audio', 'fala', 'falar', 'ouvir', 'narrar', 'narracao', 'voz', 'locucao', 'tts'],
    imageHint: [
        'imagem', 'foto', 'figura', 'desenho', 'marca', 'marcas', 'logo', 'logotipo',
        'nota fiscal', 'recibo', 'cupom fiscal', 'documento', 'fatura', 'objeto', 'objetos',
        'tag', 'tags', 'palavra-chave', 'palavras-chave', 'ocr', 'descreva', 'descrever', 'legenda'
    ]
};

/**
 * @param {Object} params
 * @param {string} params.message - texto digitado pelo usuário
 * @param {boolean} params.hasFile - se um arquivo foi anexado
 * @param {string} [params.fileMimetype] - mimetype do arquivo anexado
 * @returns {{ intent: string }}
 */
function classify({ message, hasFile, fileMimetype }) {
    const text = normalize(message);

    const isAudioFile = hasFile && fileMimetype && fileMimetype.startsWith('audio/');
    const isImageOrPdf = hasFile && fileMimetype &&
        (fileMimetype.startsWith('image/') || fileMimetype === 'application/pdf');

    // Um arquivo de áudio anexado só faz sentido para transcrição.
    if (isAudioFile) {
        return { intent: 'transcribe' };
    }

    // Arquivo de imagem ou PDF: decide qual recurso de visão usar.
    if (isImageOrPdf) {
        if (includesAny(text, WORDS.brands)) return { intent: 'brands' };
        if (includesAny(text, WORDS.document)) return { intent: 'document-intelligence' };
        if (includesAny(text, WORDS.objects)) return { intent: 'objects' };
        if (includesAny(text, WORDS.tags)) return { intent: 'tags' };
        if (includesAny(text, WORDS.read)) return { intent: 'read' };
        if (includesAny(text, WORDS.describe)) return { intent: 'describe' };
        // Sem palavra-chave clara: faz uma análise combinada (padrão útil).
        return { intent: 'analyze' };
    }

    // Sem arquivo anexado.
    if (includesAny(text, WORDS.transcribe)) return { intent: 'need-audio-file' };
    if (includesAny(text, WORDS.language)) return { intent: 'language' };
    if (includesAny(text, WORDS.tts)) return { intent: 'tts' };
    if (includesAny(text, WORDS.imageHint)) return { intent: 'need-image-file' };

    return { intent: 'help' };
}

// Extrai o texto a ser falado a partir da mensagem do usuário.
// Convenção: tudo depois de ":" é o conteúdo; sem ":", usa a
// mensagem inteira.
function extractSpeechText(message) {
    const parts = (message || '').split(':');
    if (parts.length > 1) {
        return parts.slice(1).join(':').trim();
    }
    return (message || '').trim();
}

module.exports = { classify, detectVoice, wantsAudioToo, normalize, extractSpeechText };
