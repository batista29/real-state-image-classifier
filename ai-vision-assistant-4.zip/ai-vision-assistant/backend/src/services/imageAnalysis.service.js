const axios = require('axios');

const analyze = async (fileBuffer, features, language = 'pt') => {
  const endpoint = process.env.IMAGE_ANALYSIS_ENDPOINT;
  const key = process.env.IMAGE_ANALYSIS_KEY;
  if (!endpoint || !key) throw new Error('IMAGE_ANALYSIS_ENDPOINT/IMAGE_ANALYSIS_KEY não configurados.');

  const url = `${endpoint.replace(/\/$/, '')}/computervision/imageanalysis:analyze`;

  try {
    const { data } = await axios.post(url, fileBuffer, {
      params: {
        'api-version': process.env.IMAGE_ANALYSIS_API_VERSION || '2024-02-01',
        features: features.join(','),
        language
      },
      headers: {
        'Ocp-Apim-Subscription-Key': key,
        'Content-Type': 'application/octet-stream'
      },
      maxBodyLength: Infinity
    });
    return data;
  } catch (error) {
    // Repassa a mensagem real da Azure (ex.: "The feature 'Caption' is not
    // supported in this region") em vez do "Request failed with status code 400"
    // genérico do axios, para facilitar o diagnóstico.
    const azureError = error.response?.data?.error;
    const wrapped = new Error(azureError?.message || error.message);
    wrapped.status = error.response?.status;
    wrapped.details = error.response?.data;
    wrapped.azureCode = azureError?.code;
    throw wrapped;
  }
};

module.exports = { analyze };
