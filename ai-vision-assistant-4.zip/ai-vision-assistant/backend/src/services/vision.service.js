const axios = require('axios');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

const document_intelligence = async (fileBuffer) => {
  const endpoint = process.env.VISION_ENDPOINT;
  const key = process.env.VISION_KEY;
  if (!endpoint || !key) throw new Error('VISION_ENDPOINT/VISION_KEY não configurados.');
  const url = `${endpoint.replace(/\/$/, '')}/documentintelligence/documentModels/prebuilt-layout:analyze`;
  const { data, headers, status } = await axios.post(url, fileBuffer, {
    params: { features: 'ocr.highResolution,ocr.formula,ocr.font', 'api-version': '2024-11-30' },
    headers: { 'Content-Type': 'application/octet-stream', 'Ocp-Apim-Subscription-Key': key },
    maxBodyLength: Infinity
  });
  if (status !== 202) return { text: data?.analyzeResult?.content || data };
  return { text: await document_intelligence_response(headers['operation-location']) };
};

const document_intelligence_response = async (url) => {
  if (!url) throw new Error('Azure não retornou operation-location.');
  await delay(3000);
  for (let attempts = 0; attempts < 30; attempts++) {
    const { data } = await axios.get(url, { headers: { 'Ocp-Apim-Subscription-Key': process.env.VISION_KEY } });
    if (data.status === 'succeeded') return data.analyzeResult?.content || '';
    if (data.status === 'failed') {
      const error = new Error('Falha ao analisar o documento'); error.status = 502; error.details = data; throw error;
    }
    await delay(1500);
  }
  const error = new Error('Tempo limite excedido ao aguardar a análise do documento'); error.status = 504; throw error;
};
module.exports = { document_intelligence };
