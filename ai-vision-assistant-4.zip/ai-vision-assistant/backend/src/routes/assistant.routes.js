const express = require('express');
const multer = require('multer');
const { handleAsk } = require('../services/assistant.service');

const router = express.Router();
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 25 * 1024 * 1024 }
});

// ============================================================
// ENDPOINT ÚNICO DO ASSISTENTE
// ------------------------------------------------------------
// Recebe uma mensagem em linguagem natural (campo "message")
// e, opcionalmente, um arquivo (campo "file": imagem, PDF ou
// áudio). A partir do texto e do tipo de arquivo, decide
// internamente qual serviço da Azure deve ser chamado.
// ============================================================

router.post('/ask', upload.single('file'), async (req, res, next) => {
    try {
        const message = (req.body.message || '').trim();

        if (!message && !req.file) {
            return res.status(400).json({ error: 'Digite uma mensagem ou anexe um arquivo.' });
        }

        const result = await handleAsk({ message, file: req.file });

        res.json(result);
    } catch (error) {
        next(error);
    }
});

module.exports = router;
