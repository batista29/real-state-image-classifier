const express = require('express');
const multer = require('multer');
const { document_intelligence } = require('../services/vision.service');
const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });
router.post('/document-intelligence', upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Envie um arquivo no campo file.' });
    res.json(await document_intelligence(req.file.buffer));
  } catch (error) { next(error); }
});
module.exports = router;
