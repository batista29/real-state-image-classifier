const express = require('express');
const axios = require('axios');
const router = express.Router();
router.post('/analyze-text', async (req, res, next) => {
  try {
    const { plainText } = req.body;
    if (!plainText || typeof plainText !== 'string') return res.status(400).json({ error: 'Envie plainText.' });
    const url = `${process.env.LANGUAGE_ENDPOINT}/language/:analyze-text`;
    const { data } = await axios.post(url, {
      kind: 'EntityRecognition,SentimentAnalysis',
      parameters: { modelVersion: 'latest', opinionMining: 'True' },
      analysisInput: { documents: [{ id: '1', language: 'pt', text: plainText }] }
    }, { params: { 'api-version': '2023-04-01' }, headers: { 'Content-Type':'application/json','Ocp-Apim-Subscription-Key':process.env.LANGUAGE_KEY } });
    res.json(data);
  } catch (error) { next(error); }
});
module.exports = router;
