const express = require('express');
const multer = require('multer');
const { detectBrands } = require('../services/legacyVision.service');
const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });
router.post('/brands', upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Envie uma imagem no campo file.' });
    res.json(await detectBrands(req.file.buffer));
  } catch (error) { next(error); }
});
module.exports = router;
