const express = require('express');
const multer = require('multer');
const { fast_transcription, text_to_speech } = require('../services/speech.service');
const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });
const escapeXml = text => String(text).replace(/[<>&'"]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;',"'":'&apos;','"':'&quot;'}[c]));
router.post('/fast-transcription', upload.single('audio'), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Envie um áudio no campo audio.' });
    const locales = req.body.locales ? req.body.locales.split(',').map(x => x.trim()) : ['pt-BR'];
    res.json(await fast_transcription(req.file.buffer, req.file.originalname, { locales }));
  } catch (error) { next(error); }
});
router.post('/text-to-speech', async (req, res, next) => {
  try {
    const { text, locale = 'pt-BR', voice = 'pt-BR-FranciscaNeural', outputFormat = 'audio-16khz-128kbitrate-mono-mp3' } = req.body;
    if (!text || typeof text !== 'string') return res.status(400).json({ error: 'Informe o texto.' });
    const ssml = `<speak version='1.0' xml:lang='${escapeXml(locale)}'><voice xml:lang='${escapeXml(locale)}' name='${escapeXml(voice)}'>${escapeXml(text)}</voice></speak>`;
    const audio = await text_to_speech(ssml, outputFormat);
    res.type('audio/mpeg').send(Buffer.from(audio));
  } catch (error) { next(error); }
});
module.exports = router;
