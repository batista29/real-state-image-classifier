require('dotenv').config();

const path = require('path');
const express = require('express');
const cors = require('cors');

const routes = require('./src/routes');
const errorHandler = require('./src/middlewares/errorHandler');

const app = express();

app.use(cors());

app.use(express.json({
    limit: '2mb'
}));

// ==============================
// API
// ==============================

app.use('/api', routes);

// ==============================
// FRONTEND
// ==============================

const frontendPath = path.join(__dirname, '../frontend');

app.use(express.static(frontendPath));

// ==============================
// FRONTEND FALLBACK
// ==============================

app.use((req, res, next) => {

    // Não intercepta requisições da API
    if (req.path.startsWith('/api')) {
        return next();
    }

    // Para qualquer outra rota, retorna o frontend
    res.sendFile(path.join(frontendPath, 'index.html'));
});

// ==============================
// ERROR HANDLER
// ==============================

app.use(errorHandler);

// ==============================
// SERVER
// ==============================

const port = process.env.PORT || 3000;

app.listen(port, () => {
    console.log(`AI Vision Assistant: http://localhost:${port}`);
});