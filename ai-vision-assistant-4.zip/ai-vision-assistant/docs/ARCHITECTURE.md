# Arquitetura

```text
Browser (HTML/CSS/JS)
        |
        | HTTP /api
        v
Node.js + Express
   |       |        |
   v       v        v
Document  Image    Speech
Intel.    Analysis  TTS/STT
   |       |        |
   +-------+--------+
           |
           v
       Azure AI
```

## Segurança

- Chaves somente no backend.
- `.env` não deve ser versionado.
- Frontend chama apenas `/api/...`.

## Nota fiscal

1. Upload multipart.
2. Document Intelligence faz OCR.
3. Backend devolve o texto.
4. Frontend envia texto ao TTS.
5. Áudio é reproduzido no navegador.
